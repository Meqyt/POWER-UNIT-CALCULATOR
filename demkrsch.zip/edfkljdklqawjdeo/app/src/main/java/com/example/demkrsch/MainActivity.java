package com.example.demkrsch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    private Button view_tab, conf, kill;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButton();

    }
    public void addListenerOnButton (){
        Button view_tab = findViewById(R.id.viewtables);
        Button conf = findViewById(R.id.conf);
        Button kill = findViewById(R.id.kill);
        view_tab.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(MainActivity.this,
                                MainActivity2.class);
                        startActivity(intent);
                    }
                }
        );
        conf.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        DBHelper helper = new DBHelper(MainActivity.this);
                        Intent intent = new Intent(MainActivity.this,
                                Configuration.class);
                        startActivity(intent);
                        helper.insertSocket("lga1151");
                        helper.insertSocket("lga1151v2");
                        helper.insertSocket("lga1200");
                        helper.insertSocket("lga1700");
                        helper.insertSocket("AM3+");
                        helper.insertSocket("AM4");
                        helper.insertSocket("AM5");
                        helper.insertMotherboard("Asus Prime H410m-k","ASUS","H410","mATX",3);
                        helper.insertMotherboard("GIGABYTE A520M K V2","GYGABYTE","A520","mATX",6);
                        helper.insertMotherboard("MSI PRO B660M-E DDR4","MSI","B660","mATX",4);
                        helper.insertCPU("Intel Core i3 10100f","INTEL",4,8,3600,65,3);
                        helper.insertCPU("AMD Ryzen 5 5500","RYZEN",6,12,3600,65,6);
                        helper.insertCPU("Intel Core i5-13400F","INTEL",10,16,2500,65,4);
                        helper.insertGPU("MSI VENTUS Geforce GTX 1660 Super","NVIDIA","MSI",6,1610,120);
                        helper.insertGPU("GIGABYTE GeForce GT 1030 OC","NVIDIA","GIGABYTE",2,1265,30);
                        helper.insertGPU("GIGABYTE AMD Radeon RX 6900 XT GAMING OC","NVIDIA","GIGABYTE",16,1865,300);
                        helper.insertPUNIT("AeroCool VX PLUS 600W","AeroCool","NO","NO",600);
                        helper.insertPUNIT("Chieftec Proton 600W BULK","Chieftec","YES","80 plus bronze",600);
                        helper.insertPUNIT("Silverstone ST1500-TI","Silverstone","YES","80 plus titanium",1500);

                    }
                }
        );
        kill.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        finishAffinity();
                    }
                }
        );
    }
}