package com.example.demkrsch;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class Punit extends AppCompatActivity {
    private Button backpunit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_punit);
        addListenerOnButton();
    }

    public void addListenerOnButton() {
        Button backpunit = findViewById(R.id.backpunit);
        backpunit.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Punit.this,
                                MainActivity2.class);
                        startActivity(intent);
                    }
                }
        );
    }
}