package com.example.demkrsch;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;
import android.database.Cursor;
import android.widget.Toast;

public class DBHelper extends SQLiteOpenHelper {
    SQLiteDatabase db;
    Context context;
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "CPP";
    private static final String SOCKET = "socket";
    private static final String MOTHERBOARD = "motherboard";
    private static final String CPU = "cpu";
    private static final String GPU = "gpu";
    private static final String POWER_UNIT = "power_unit";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + SOCKET + "(_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL);");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + MOTHERBOARD + "(_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, chipset TEXT NOT NULL, manufacturer TEXT, form_factor TEXT, sockid INTEGER references socket(_id));");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + CPU + "(_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, manufacturer TEXT NOT NULL, cores INTEGER NOT NULL, threads INTEGER NOT NULL, frequency INT NOT NULL, tdp INTEGER NOT NULL,sockid references socket (_id));");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + GPU + "(_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, manufacturer TEXT NOT NULL, vendor TEXT, frequency INTEGER NOT NULL, vram INTEGER NOT NULL, tdp INTEGER NOT NULL);");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + POWER_UNIT + "(_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, manufacturer TEXT NOT NULL, APFC TEXT NOT NULL, sertificate TEXT ,output_power INTEGER NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public void insertSocket(String name) {
        db = this.getWritableDatabase();
        ContentValues socketValues = new ContentValues();
        socketValues.put("name", name);
        db.insert(SOCKET, null, socketValues);

    }

    public void insertMotherboard(String name, String manufacturer, String chipset, String form_factor, int sockid) {
        db = this.getWritableDatabase();
        ContentValues mothValues = new ContentValues();
        mothValues.put("name", name);
        mothValues.put("chipset", chipset);
        mothValues.put("manufacturer", manufacturer);
        mothValues.put("form_factor", form_factor);
        mothValues.put("sockid", sockid);
        db.insert(MOTHERBOARD, null, mothValues);

    }

    public void insertCPU(String name, String manufacturer, int cores, int threads, int frequency, int tdp, int sockid) {
        db = this.getWritableDatabase();
        ContentValues cpuValues = new ContentValues();
        cpuValues.put("name", name);
        cpuValues.put("manufacturer", manufacturer);
        cpuValues.put("cores", cores);
        cpuValues.put("threads", threads);
        cpuValues.put("frequency", frequency);
        cpuValues.put("tdp", tdp);
        cpuValues.put("sockid", sockid);
        db.insert(CPU, null, cpuValues);

    }

    public void insertGPU(String name, String manufacturer, String vendor, int vram, int frequency, int tdp) {
        db = this.getWritableDatabase();
        ContentValues gpuValues = new ContentValues();
        gpuValues.put("name", name);
        gpuValues.put("manufacturer", manufacturer);
        gpuValues.put("vendor", vendor);
        gpuValues.put("frequency", frequency);
        gpuValues.put("vram", vram);
        gpuValues.put("tdp", tdp);
        db.insert(GPU, null, gpuValues);

    }

    public void insertPUNIT(String name, String manufacturer, String APFC, String sertificate, int output_power) {
        db = this.getWritableDatabase();
        ContentValues puValues = new ContentValues();
        puValues.put("name", name);
        puValues.put("manufacturer", manufacturer);
        puValues.put("APFC", APFC);
        puValues.put("sertificate", sertificate);
        puValues.put("output_power", output_power);
        db.insert(POWER_UNIT, null, puValues);

    }

    public void insertAll(View view){
        insertSocket("lga1151");
        insertSocket("lga1151v2");
        insertSocket("lga1200");
        insertSocket("lga1700");
        insertSocket("AM3+");
        insertSocket("AM4");
        insertSocket("AM5");
        insertMotherboard("Asus Prime H410m-k","ASUS","H410","mATX",3);
        insertMotherboard("GIGABYTE A520M K V2","GYGABYTE","A520","mATX",6);
        insertMotherboard("MSI PRO B660M-E DDR4","MSI","B660","mATX",4);
        insertCPU("Intel Core i3 10100f","INTEL",4,8,3600,65,3);
        insertCPU("AMD Ryzen 5 5500","RYZEN",6,12,3600,65,6);
        insertCPU("Intel Core i5-13400F","INTEL",10,16,2500,65,4);
        insertGPU("MSI VENTUS Geforce GTX 1660 Super","NVIDIA","MSI",6,1610,120);
        insertGPU("GIGABYTE GeForce GT 1030 OC","NVIDIA","GIGABYTE",2,1265,30);
        insertGPU("GIGABYTE AMD Radeon RX 6900 XT GAMING OC","NVIDIA","GIGABYTE",16,1865,300);
        insertPUNIT("AeroCool VX PLUS 600W","AeroCool","NO","NO",600);
        insertPUNIT("Chieftec Proton 600W BULK","Chieftec","YES","80 plus bronze",600);
        insertPUNIT("Silverstone ST1500-TI","Silverstone","YES","80 plus titanium",1500);

    }
    public Cursor getData(String tableName) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + tableName, null);

        return cursor;
    }
}


