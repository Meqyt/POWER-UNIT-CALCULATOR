package com.example.demkrsch;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.TextView;

public class Motherboard extends AppCompatActivity {
    DBHelper dbHelper;
    SQLiteDatabase db;
    private Button backmoth, buview;
    private static int AUTISM = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motherboard);
        addListenerOnButton();
        dbHelper = new DBHelper(this);
    }

    public void addListenerOnButton() {
        Button backmoth = findViewById(R.id.backmoth);
        Button buview = findViewById(R.id.buttonview);
        TextView textView = findViewById(R.id.textView4);
        backmoth.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(Motherboard.this,
                                MainActivity2.class);
                        startActivity(intent);
                    }
                }
        );
        buview.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View view) {
                    // Вызываем метод getData для получения данных из таблицы "gpu"
                    Cursor cursor = dbHelper.getData("gpu");
                    if (cursor.getCount() > 0) {cursor.moveToFirst();

                        textView.setText(cursor.getString(cursor.getColumnIndex("name")));
                    }


                    cursor.close();
                }
            });
    }
}